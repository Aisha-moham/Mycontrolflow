import Cocoa

var str = "Hello, playground"
// My 10 list of items Array.


var myItems : [String] = ["Purse", "Shoes", "Lipgloss", " hairproducts", "box"]
myItems.append("rings")
myItems += ["books", "Money", "earrings" , "clothes" ]

print(" myItems list contains \(myItems.count) items.")

if myItems.isEmpty {
    print ("myItems list is empty.")
} else {
print(" myItem list is not empty")
}
var firstItem = myItems [2]
var secondItem = myItems [5]
var thirdItems = myItems [8]

for myItems in myItems {
    print(myItems)
}
let sortedmyItems = myItems.sorted()
print(sortedmyItems)


var myArray: [String] = (myItems)
var numOfElements = myArray.count - 1
for _ in 0...numOfElements{
    for j in 0...numOfElements - 1{
        print("\(myArray[j])  \(myArray[j + 1]) ")
        if (myArray[j] > myArray[j + 1]){
            print("swap")
            myArray.swapAt(j, j + 1)
        }
    }
}
print(myArray)
